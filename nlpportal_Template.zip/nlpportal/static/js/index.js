$(document).ready(function(){

$("#add_dataset").hide();

$("body").on("click","#addnew", function(){
    $("#all_dataset").hide();
    $("#add_dataset").show();

    $("#alldataset").removeClass("bottomline");
    $("#addnew").addClass("bottomline");

});

$("body").on("click","#alldataset", function(){
    $("#all_dataset").show();
    $("#add_dataset").hide();

    $("#alldataset").addClass("bottomline");
    $("#addnew").removeClass("bottomline");

});


});