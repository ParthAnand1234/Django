from django import forms

class DatasetForm(forms.Form):
    nameOfdata = forms.CharField(max_length=30)
    noOfClass = forms.CharField(max_length=30)
    nameOfClass = forms.CharField(max_length=30)
    desc = forms.CharField(max_length=30)
    filecsv = forms.FileField()


class LabelForm(forms.Form):
    noOfClass = forms.CharField(max_length=30)
    url = forms.CharField(max_length=30)
    sent = forms.CharField(max_length=300)
