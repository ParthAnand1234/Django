from django.shortcuts import render
from . import forms
from django.conf import settings
import os

# Create your views here.

def index(request):
    data = "Work here"

    return render(request, "home/index.html", {"data": data})



